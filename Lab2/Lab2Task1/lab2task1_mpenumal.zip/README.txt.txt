SER598 - Web Application Programming

Lab2 Task1:
Please change the build.xml and build.properties files based on the testing machine configuration.
No class member variables were used, to achieve thread safety.