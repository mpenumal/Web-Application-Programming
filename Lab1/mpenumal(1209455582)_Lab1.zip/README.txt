SER598 - Web Application Programming

Lab1:

#1
Approach:
To maintain a running total of a single client, we initialize an integer variable ("total" in this case) and
the values from client side will be added to this variable and stored in it until the connection is open.

Example:
Start 2 command prompts, 1 for server and 1 for client.
For server, run
	javac SockServer1.java
	java SockServer1

For client, run
	javac SockClient1.java
	java SockClient1 20
This gives result = 20

Again for client, run
	java SockClient1 50
This gives result = 70

#2
Approach:
To reset a running total of a single client, we accept "r/R" from client side and send it to server code.
Here, we check if the character received is "r/R" and if true, we set the integer variable ("total" in this 
case) equal to zero.

Example:
Start 2 command prompts, 1 for server and 1 for client.

For server run,
	javac SockServer2.java
	java SockServer2

For client run,
	javac SockClient2.java
	java SockClient2 20
This gives result = 20

Again for client, run
	java SockClient2 r
This gives result = 0

#3
Approach:
To maintain separate running totals for different clients, we use a HashMap. In the HashMap, we store 
the clientId and the associated value. Everytime a client call is made with a specific clientId, we 
check if it is available in the HashMap and insert or update it accordingly.

Example:
Start 2 command prompts, 1 for server and 1 for client.

For server run,
	javac SockServer3.java
	java SockServer3

For client run,
	javac SockClient3.java
	java SockClient3 1 50
This gives result = 50

Again for client, run
	java SockClient3 2 25
This gives result = 25

Again for client, run
	java SockClient3 1 20
This gives result = 70

#4
Approach:
To send and receive correct integer value, the integer values are converted to byte arrays.
The conversion between int and byte[] is done using java.nio.ByteBuffer.

Example:
Start 2 command prompts, 1 for server and 1 for client.

For server run,
	javac SockServer4.java
	java SockServer4

For client run,
	javac SockClient4.java
	java SockClient4 1 300
This gives result = 300

Again for client, run
	java SockClient4 1 350
This gives result = 650

#5
Approach:
To persist the state of the running total in an XML file, We check if there is an XML file 
already created or not. If not, we create it. Then we check if the current clientId is present 
in the XML file. If present, we update it. Else, we insert a new element.
This behavior is achieved with the help xml related packages available in java.
The entire XML handling logic is written as a separate class as none of this logic belongs with the server code.

Example:
Start 2 command prompts, 1 for server and 1 for client.

For server run,
	javac SockServer5.java
	java SockServer5

For client run,
	javac SockClient5.java
	java SockClient5 1 300
This gives result = 300

Again for client, run
	java SockClient5 1 350
This gives result = 650

Again for client, run
	java SockClient5 2 50
This gives result = 50

The final results can be seen in the newly created xml file named "clientTotals.xml".

#6
Approach:
To implement multi-threading, we create a new class that extends java.lang.Thread.
In the server logic, we only create an instance of this class and "start" it.
The entire handling of client values is done from the "run" function in the new class.
This internally is handling the thread safety part of the requirement and the throughput is also high.

Example:
Start 6 command prompts, 1 for server and 5 for clients.

For server, run
	javac SockServer6.java
	java SockServer6 10000  // To get a 10 second delay.
For one of the clients, run
	javac SockClient6.java

From client cmd 1, run	
	java SockClient6 1 100
This gives result = 100

From client cmd 2, run	
	java SockClient6 1 200
This gives result = 300

From client cmd 3, run	
	java SockClient6 1 300
This gives result = 600

From client cmd 4, run	
	java SockClient6 1 400
This gives result = 1000

From client cmd 5, run	
	java SockClient6 1 500
This gives result = 1500

The time taken to obtain results depends on the duration between each client call.
If all the call are made at approximately the same time, then all the results will be available approximately after 10 seconds. 
The final results can be seen in the newly created xml file named "clientTotals.xml".